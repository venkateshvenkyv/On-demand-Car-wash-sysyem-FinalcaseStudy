export class CarDetails{
     name : String;
	 emailId : String;
	 contactNumber : String;
	 carModel : String;
	 carType : String;
	 serviceType : String;
	 preferredTime : String;
	 message : String;
	 address : String;
	 subscription : String;
}