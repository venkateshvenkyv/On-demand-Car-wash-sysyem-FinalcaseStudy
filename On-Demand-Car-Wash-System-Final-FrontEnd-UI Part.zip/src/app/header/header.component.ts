import { Component, OnInit } from '@angular/core';
import { User} from '../User';
import { Router } from '@angular/router';
import { CustomerService } from '../customer.service';

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.css']
})
export class HeaderComponent implements OnInit {
   

  usercredentials = JSON.parse(localStorage.getItem('userdetails'))
  usercardetails = JSON.parse(localStorage.getItem('BookingCarDetails'))
  isloggedin:boolean = false;
  
  constructor( private route  : Router, public apiService : CustomerService) { 
    this.apiService.loginFlag.subscribe(val => {
      this.isloggedin = val;
  });;
  }
   
  ngOnInit(): void {
    //console.log(this.usercardetails + "details")
  }

  logout(){
    // window.localStorage.removeItem('userdetails')
    // window.localStorage.removeItem('BookingCarDetails')
    this.apiService.logout();
    this.apiService.loginFlag.next(false);
    this.route.navigateByUrl('/cust-login');
  }
 
}
