import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Router } from '@angular/router';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class CarbookingService {
  [x: string]: any;

  private  baseUrl = "http://localhost:8082/";
  constructor(private http: HttpClient, private router : Router) { }

  addCarDetails(user : any): Observable<any>{
    console.log("success service")
    console.log(user);
    let url = this.baseUrl + "order/addorder";
    return this.http.post(url, user);

  }

}
