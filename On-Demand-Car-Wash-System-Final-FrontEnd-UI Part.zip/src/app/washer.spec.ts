import { Washer } from './washer';

describe('Washer', () => {
  it('should create an instance', () => {
    expect(new Washer()).toBeTruthy();
  });
});
