export class Order {

    orderId:number;
    carName:String;
    carModel:String;
    wName:String;
    washPackId:number;
    date:String;
    phoneNo:number;

}

