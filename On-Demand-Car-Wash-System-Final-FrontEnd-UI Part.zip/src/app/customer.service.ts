import { Injectable, NgZone } from '@angular/core';
import { Router } from '@angular/router';
import { BehaviorSubject, Observable, Subject } from 'rxjs';
import {HttpClient, HttpHeaders} from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class CustomerService {
  [x: string]: any;
  loginFlag = new BehaviorSubject<boolean>(false);
  private  baseUrl = "http://localhost:8083/customer";

  constructor(private http: HttpClient, private router : Router) { 
   
  }

  register(user : any): Observable<any> {
    console.log("success service")
    console.log(user);
    let url = this.baseUrl + "/subs";
    return this.http.post(url, user);
  }

//   login(userLogin : User): Observable<any>{
//     let url = this.baseUrl + "login";
//     return this.http.post(this.baseUrl +"/auth", userLogin)
//   }

//   addCarDetails(car : any) : Observable<any>{
//     console.log("car service working")
//     let url = this.baseUrl + "booking";
//     return this.http.post(url, car);
//   }
//   logout(){
    
//   }

//   isLoggedIn() {
//     return this.afAuth.authState.pipe(first()).toPromise();
//  }

//  getCarDetail(details : any){
//   let url = this.baseUrl + "getcardetails";
//   return this.http.post(url, details);

//  }

loginUser(token){

    localStorage.setItem("token",token)

    return true;

  }

  isLoggedIn()

  {

    let token = localStorage.getItem('token');
    if(token==undefined || token==="" || token==null)

    {

      return false;

    }

    else{

      return true;

    }

  }

  logout(){

    localStorage.removeItem('token');
    return true;

  }

  generateToken(credentials:any){

    return this.http.post(this.baseUrl +"/auth",credentials,{responseType:'text' as 'json'})

  }

  getToken(){

    return localStorage.getItem('token');
  }


}
