import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { AdminserviceService } from '../adminservice.service'

@Component({
  selector: 'app-adminlogin',
  templateUrl: './adminlogin.component.html',
  styleUrls: ['./adminlogin.component.css']
})
export class AdminloginComponent implements OnInit {

  registerForm: FormGroup;

   myStorage = window.localStorage;
  constructor( private route : Router, private apiService : AdminserviceService) { 
    this.registerForm = new FormGroup({
    
    
      id:new FormControl(null,Validators.required),
      username: new FormControl(null,Validators.required),
      email: new FormControl(null, Validators.required),
      password: new FormControl(null, Validators.required),
    });
  }

  isValid(controlName) {
    return this.registerForm.get(controlName).invalid && (this.registerForm.get(controlName).touched || this.registerForm.get(controlName).dirty);
  }

  register(){
    if(this.registerForm.valid){
      this.apiService.register(this.registerForm.value).subscribe(
        (data)=>{
          if(data){
            console.log("registration completed")
            localStorage.setItem('userdetails',JSON.stringify(this.registerForm.value) )
            this.route.navigateByUrl('/provider-login');
          }
          else{
            alert("User alredy registered")
          }
        },error =>{
          console.log(error +"error")
        }
      )
    }
  
     
 }

  ngOnInit(): void {
  }

}
