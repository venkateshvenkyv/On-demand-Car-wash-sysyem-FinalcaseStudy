import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Router } from '@angular/router';
import { Observable } from 'rxjs';



@Injectable({
  providedIn: 'root'
})
export class AdminserviceService {
  [x: string]: any;

  private  baseUrl = "http://localhost:8081/Admin";

  constructor(private http: HttpClient, private router : Router) { }

  register(user : any): Observable<any> {
    console.log("success service")
    console.log(user);
    let url = this.baseUrl + "/subs";
    return this.http.post(url, user);
  }



loginUser(token){

    localStorage.setItem("token",token)

    return true;

  }

  isLoggedIn()

  {

    let token = localStorage.getItem('token');
    if(token==undefined || token==="" || token==null)

    {

      return false;

    }

    else{

      return true;

    }

  }

  logout(){

    localStorage.removeItem('token')

    return true;

  }

  generateToken(credentials:any){

    return this.http.post(this.baseUrl +"/auth",credentials,{responseType:'text' as 'json'})

  }

  getToken(){

    return localStorage.getItem('token');

  }


}

