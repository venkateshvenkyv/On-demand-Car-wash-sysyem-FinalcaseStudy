 import { LoginComponent } from "./login/login.component";
 
export class Washer {
   
    id:number;
    username:String;
    email:String;
    password:String;

}

