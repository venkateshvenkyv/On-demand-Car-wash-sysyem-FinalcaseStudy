import { Injectable } from '@angular/core';
import { CanActivate, ActivatedRouteSnapshot, RouterStateSnapshot, UrlTree, Router } from '@angular/router';
import { Observable } from 'rxjs';
import { CustomerService } from './customer.service';

@Injectable({
  providedIn: 'root'
})
export class CustguardGuard implements CanActivate {
  
  constructor(private customerservice:CustomerService,private route:Router){}

  canActivate(

    next: ActivatedRouteSnapshot,


    state: RouterStateSnapshot): Observable<boolean | UrlTree> | Promise<boolean | UrlTree> | boolean | UrlTree {

    if(this.customerservice.isLoggedIn()){

      return true;

    }this.route.navigate(['/cust-login']);

      return false;

  }
  
}
