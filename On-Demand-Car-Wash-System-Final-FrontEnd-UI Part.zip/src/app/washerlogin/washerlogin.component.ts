import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { CustomerService } from '../customer.service';
import { WasherService } from '../washer.service';

@Component({
  selector: 'app-washerlogin',
  templateUrl: './washerlogin.component.html',
  styleUrls: ['./washerlogin.component.css']
})
export class WasherloginComponent implements OnInit {

  loginForm: FormGroup;
  myStorage = window.localStorage;
  constructor( private route : Router, private apiService : WasherService,private custservice:CustomerService) { 
    this.loginForm = new FormGroup({
      username: new FormControl(null, Validators.required),
      password: new FormControl(null, Validators.required)
    }); 
}

  isValid(controlName) {
    return this.loginForm.get(controlName).invalid && (this.loginForm.get(controlName).touched || this.loginForm.get(controlName).dirty);
  }

  login() {
    console.log(this.loginForm.value);
    
    if (this.loginForm.valid) {
      this.apiService.generateToken(this.loginForm.value)
        .subscribe(
          (data) => {
            if(data){
              console.log("login completed")
              // localStorage.setItem('userdetails',JSON.stringify(this.loginForm.value) )
              // console.log()
              this.apiService.loginUser(data);
              this.custservice.loginFlag.next(true);
              this.route.navigateByUrl('/orderdetails')
            }
            
            else{
              alert("invalid user")
            }
          },
          error => {
            console.log(error + 'error')
           }
        );
    }
    
    
  }

  ngOnInit(): void {
    
  }

}
