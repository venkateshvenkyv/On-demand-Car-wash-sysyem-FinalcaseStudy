package com.casestudy.venky.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.casestudy.venky.model.PaymentModel;
import com.casestudy.venky.service.PaymentService;

@RestController
public class PaymentController {
	@Autowired
	public PaymentService paymentService;

	@PostMapping("/payment")
	public PaymentModel doPayment(@RequestBody PaymentModel payment) {
		return paymentService.doPay(payment);
	}
}
