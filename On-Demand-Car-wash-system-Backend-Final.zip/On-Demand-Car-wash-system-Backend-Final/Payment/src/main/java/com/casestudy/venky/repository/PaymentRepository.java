package com.casestudy.venky.repository;

import org.springframework.data.mongodb.repository.MongoRepository;

import com.casestudy.venky.model.PaymentModel;


public interface PaymentRepository extends MongoRepository<PaymentModel, Integer> {




}
