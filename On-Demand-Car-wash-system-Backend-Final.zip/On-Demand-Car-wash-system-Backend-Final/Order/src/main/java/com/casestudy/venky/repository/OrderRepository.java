package com.casestudy.venky.repository;

import org.springframework.data.mongodb.repository.MongoRepository;

import com.casestudy.venky.model.Order;

public interface OrderRepository extends MongoRepository<Order, Integer> {

}
